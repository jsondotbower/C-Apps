﻿using System.Windows;
using RestoreDatabase2._0.Pages;
using System.IO;
using System;

namespace RestoreDatabase2._0
{
    public partial class MainWindow
    {
        private string backupD = @"D:\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\Backup";

        public MainWindow()
        {
            InitializeComponent();
            try
            {
                // checks for D drive, if it cannot find it, it will default to C
                if (Directory.Exists(backupD))
                {
                    InitializePage.NavigationService.Navigate(new DriveD());
                }
                else
                {
                    InitializePage.NavigationService.Navigate(new DriveC());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("The directory could not be found.  Error message: " + ex.Message);
            }           
        }
    }
}
