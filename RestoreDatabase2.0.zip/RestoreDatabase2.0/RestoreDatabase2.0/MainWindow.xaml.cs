﻿using System;
using System.Windows;
using RestoreDatabase2._0.Pages;

namespace RestoreDatabase2._0
{
    public partial class MainWindow
    {
        public MainWindow()
        {
            InitializeComponent();
            try
            {
                InitializePage.NavigationService.Navigate(new DriveC());
            }
            catch (Exception ex)
            {
                MessageBox.Show("The directory could not be found.  Error message: " + ex.Message);
            }           
        }
    }
}
