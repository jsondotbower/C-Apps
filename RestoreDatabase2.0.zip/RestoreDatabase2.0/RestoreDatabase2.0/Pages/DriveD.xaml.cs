﻿using System;
using System.IO;
using System.Windows;
using RestoreDatabase2._0.Classes;
using System.Data.SqlClient;
using RestoreDatabase2._0.Windows;
using Microsoft.Win32;

namespace RestoreDatabase2._0.Pages
{
    public partial class DriveD
    {
        public DriveD()
        {
            InitializeComponent();
            Refresh();
        }

        private void BtnRestore_Click(object sender, RoutedEventArgs e)
        {
            if (LblBackup.Content == null)
            {
                MessageBox.Show(@"You must select a database!");
            }
            else
            {
                string dbTrim = Path.GetFileNameWithoutExtension(LblBackup.Content.ToString());
                var dr = MessageBox.Show("Restore database " + dbTrim + "?",
                    "Confirm Restore", MessageBoxButton.YesNo);
                if (dr == MessageBoxResult.Yes)
                {
                    new PleaseWaitDriveD(LblBackup.Content.ToString(), TxtDcKey.ToString(), TxtRegisterKey.ToString());
                }
                Refresh();
            }
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            if (LblBackup.Content == null)
            {
                MessageBox.Show(@"You must select a database!");
            }
            else
            {
                string database = LblBackup.Content.ToString();
                string dbTrim = Path.GetFileNameWithoutExtension(database);
                var con = Db.GetMasterConn();
                try
                {
                    var dr = MessageBox.Show("Create database " + dbTrim + "?",
                        "Confirm Creation", MessageBoxButton.YesNo);
                    if (dr == MessageBoxResult.Yes)
                    {
                        con.Open();
                        var query = DriveQueries.CreateDatabaseD(database, dbTrim);
                        var command = new SqlCommand(query, con);
                        var cd = new CreateDatabase();

                        command.CommandTimeout = 0;
                        command.ExecuteNonQuery();
                        MessageBox.Show("Database " + dbTrim +
                                        " created successfully!  Go to SQL and refresh your databases to see it.");
                        cd.Hide();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void BtnOpenFile_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog();
            dlg.FileName = "Document";
            dlg.DefaultExt = ".bak";
            dlg.Filter = "Backup (.bak)|*.bak";

            var result = dlg.ShowDialog();

            if (result == true)
            {
                string filename = dlg.FileName;
                LblBackup.Content = filename;
            }
        }

        private void Refresh()
        {
            LblDbVersion.Content = LoadStoreInfo.LoadDbVersion(LblDbVersion.Content.ToString());
            LblStore.Content = LoadStoreInfo.LoadStorename(LblStore.Content.ToString());
            TxtStoreKey.Text = LoadStoreInfo.LoadStoreKey(TxtStoreKey.Text);
            TxtDcKey.Text = LoadStoreInfo.LoadDataCenter(TxtDcKey.Text);
            TxtRegisterKey.Text = LoadStoreInfo.LoadRegister(TxtRegisterKey.Text);
        }

        private void BtnBackup_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new SaveFileDialog();
            dlg.Title = "Create database backup";
            dlg.Filter = "Backup Files (.bak)|*.bak";
            dlg.DefaultExt = "bak";
            dlg.AddExtension = true;
            var result = dlg.ShowDialog();

            if (result == true)
            {
                string filename = dlg.FileName;
                LblBackup.Content = filename;
            }
        }

        private void BtnSaveBackup_Click(object sender, RoutedEventArgs e)
        {
            if (LblBackup.Content == null)
            {
                MessageBox.Show(@"You must select a database!");
            }

            try
            {               
                string database = LblBackup.Content.ToString();
                string dbTrim = Path.GetFileNameWithoutExtension(database);

                var dr = MessageBox.Show("Backup database " + dbTrim + "?",
                    "Confirm Backup", MessageBoxButton.YesNo);
                if (dr == MessageBoxResult.Yes)
                {
                    var con = Db.GetMasterConn();
                    con.Open();
                    var query = Classes.BackupDatabase.BackupDb(database);
                    var command = new SqlCommand(query, con);
                    var bd = new Windows.BackupDatabase();
                    command.CommandTimeout = 0;
                    command.ExecuteNonQuery();
                    MessageBox.Show("Database " + dbTrim +
                                        " backed up successfully!  It will now be saved to your selected directory.");
                    bd.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}