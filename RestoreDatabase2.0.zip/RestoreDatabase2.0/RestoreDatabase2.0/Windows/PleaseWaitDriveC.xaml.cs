﻿using RestoreDatabase2._0.Classes;
using RestoreDatabase2._0.Pages;

namespace RestoreDatabase2._0.Windows
{
    public partial class PleaseWaitDriveC
    {
        public string LblBackup, DcKey, RegKey;

        public PleaseWaitDriveC(string backup, string dcKey, string regKey)
        {
            InitializeComponent();
            Show();
            LblBackup = backup;
            DcKey = dcKey;
            RegKey = regKey;
            DoWork();
        }

        private void DoWork()
        {
            Dispatcher.Invoke(() =>
            {
                var driveC = new DriveC();
                driveC.LblBackup.Content = LblBackup;
                driveC.TxtDcKey.Text = DcKey;
                driveC.TxtRegisterKey.Text = RegKey;
                RestoreDatabase.ExecuteRestore(LblBackup, DcKey, RegKey);
                Close();
            });
        }
    }
}