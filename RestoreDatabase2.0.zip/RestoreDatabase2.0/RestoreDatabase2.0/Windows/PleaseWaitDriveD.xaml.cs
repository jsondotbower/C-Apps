﻿using RestoreDatabase2._0.Classes;
using RestoreDatabase2._0.Pages;

namespace RestoreDatabase2._0.Windows
{
    public partial class PleaseWaitDriveD
    {
        public string LblBackup, DcKey, RegKey;

        public PleaseWaitDriveD(string backup, string dcKey, string regKey)
        {
            InitializeComponent();
            Show();
            LblBackup = backup;
            DcKey = dcKey;
            RegKey = regKey;
            DoWork();
        }

        private void DoWork()
        {
            Dispatcher.Invoke(() =>
            {
                var driveD = new DriveD();
                driveD.LblBackup.Content = LblBackup;
                driveD.TxtDcKey.Text = DcKey;
                driveD.TxtRegisterKey.Text = RegKey;
                RestoreDatabase.ExecuteRestoreD(LblBackup, DcKey, RegKey);
                Close();
            });
        }
    }
}