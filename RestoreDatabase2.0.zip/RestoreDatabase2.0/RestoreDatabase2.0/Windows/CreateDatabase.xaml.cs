﻿namespace RestoreDatabase2._0
{
    public partial class CreateDatabase
    {
        public CreateDatabase()
        {
            InitializeComponent();
            Show();
        }
    }
}