﻿namespace RestoreDatabase2._0.Windows
{
    public partial class BackupDatabase
    {
        public BackupDatabase()
        {
            InitializeComponent();
            Show();
        }
    }
}