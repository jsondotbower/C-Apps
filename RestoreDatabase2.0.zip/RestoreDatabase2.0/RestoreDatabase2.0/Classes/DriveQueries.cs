﻿namespace RestoreDatabase2._0.Classes
{
    public static class DriveQueries
    {
        public static string GetBackupQueryC(string database)
        {
            return @"USE [master] ;
                    ALTER DATABASE [ARSNET] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;" +
                    @"RESTORE DATABASE [ARSNET] FROM  DISK = N'" +
                    database + "' WITH  FILE = 1, " +
                    @"MOVE N'ARSNET' TO N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\ARSNET.mdf',  MOVE N'ARSNET_log' TO N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\ARSNET.ldf',
                    KEEP_REPLICATION,  NOUNLOAD,  REPLACE,  STATS = 5" +
                    @"ALTER DATABASE [ARSNET] SET MULTI_USER";
        }

        public static string CreateDatabaseC(string database, string dbTrim)
        {
            return "USE [master]" +
                   @"RESTORE DATABASE [" + dbTrim + "] FROM  " +
                   @"DISK = N'" + database + "' WITH  FILE = 1, " +
                   @"MOVE N'ARSNET' TO N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\" + dbTrim + ".mdf',  MOVE N'ARSNET_log' " +
                   @"TO N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\" + dbTrim + "_log.ldf',  " +
                   @"NOUNLOAD,  REPLACE,  STATS = 5";
        }

        public static string GetBackupQueryD(string database)
        {
            return @"USE [master] ;
                    ALTER DATABASE [ARSNET] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;" +
                    @"RESTORE DATABASE [ARSNET] FROM  DISK = N'" +
                    database + "' WITH  FILE = 1, " +
                    @"MOVE N'ARSNET' TO N'D:\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\ARSNET.mdf',  MOVE N'ARSNET_log' TO N'D:\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\ARSNET.ldf',
                    KEEP_REPLICATION,  NOUNLOAD,  REPLACE,  STATS = 5" +
                    @"ALTER DATABASE [ARSNET] SET MULTI_USER";
        }

        public static string CreateDatabaseD(string database, string dbTrim)
        {
            return "USE [master]" +
                   @"RESTORE DATABASE [" + dbTrim + "] FROM  " +
                   @"DISK = N'" + database + "' WITH  FILE = 1, " +
                   @"MOVE N'ARSNET' TO N'D:\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\" + dbTrim + ".mdf',  MOVE N'ARSNET_log' " +
                   @"TO N'D:\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\" + dbTrim + "_log.ldf',  " +
                   @"NOUNLOAD,  REPLACE,  STATS = 5";
        }
    }
}