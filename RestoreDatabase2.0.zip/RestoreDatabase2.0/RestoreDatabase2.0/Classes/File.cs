﻿namespace RestoreDatabase2._0.Classes
{
    public class File
    {
        public File(string fullPath, string name)
        {
            FullPath = fullPath;
            Name = name;
        }
        public string FullPath
        {
            get;
            set;
        }
        public string Name
        {
            get;
            set;
        }
    }
}