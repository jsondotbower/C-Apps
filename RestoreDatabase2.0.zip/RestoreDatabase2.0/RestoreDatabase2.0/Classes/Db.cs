﻿using System.Data.SqlClient;

namespace RestoreDatabase2._0.Classes
{
    public static class Db
    {
        public static SqlConnection GetMasterConn()
        {
            return new SqlConnection(GetConMaster());
        }
        public static object Query(string sql)
        {
            using (var conn = new SqlConnection(GetConString()))
            {
                using (var cmd = new SqlCommand(sql, conn))
                {
                    conn.Open();
                    return cmd.ExecuteScalar();
                }
            }
        }
        public static void NonQuery(string sql)
        {
            using (var sqlconn = new SqlConnection(GetConString()))
            {
                using (var sqlcmd = new SqlCommand(sql, sqlconn))
                {
                    sqlconn.Open();
                    sqlcmd.ExecuteNonQuery();
                }
            }
        }
        private static string GetConString()
        {
            return @"Server=localhost; Database=arsnet; User Id=sa; Password=ars26R2";
        }
        private static string GetConMaster()
        {
            return @"Server=localhost; Database=master; User Id=sa; Password=ars26R2";
        }
    }
}