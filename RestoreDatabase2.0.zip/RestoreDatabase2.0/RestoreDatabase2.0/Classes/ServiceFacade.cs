﻿using System.Collections.ObjectModel;
using System.IO;

namespace RestoreDatabase2._0.Classes
{
    public sealed class ServiceFacade
    {
        private static ServiceFacade instance;
        public static ServiceFacade Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ServiceFacade();
                    instance.Initialize();
                }
                return instance;
            }
        }
        public ObservableCollection<Drive> Drives
        {
            get;
            private set;
        }
        private void Initialize()
        {
            Drives = new ObservableCollection<Drive>();
            foreach (DriveInfo driveInfo in DriveInfo.GetDrives())
            {
                Drives.Add(new Drive(driveInfo.Name, driveInfo.IsReady));
            }
        }
    }
}
