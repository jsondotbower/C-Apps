﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Navigation;

namespace RestoreDatabase2._0.Classes
{
    public class StoreInfo
    {
        public string DbVersion { get; set; }
        public string StoreName { get; set; }
        public string StoreKey { get; set; }
        public string DcKey { get; set; }
        public string RegKey { get; set; }
    }

    public static class Refresh
    {
        //internal static void GetStoreInfo(List<StoreInfo> infoList)
        // {
        //     foreach (var info in infoList)
        //     {
        //         LblDbVersion.Content = info.DbVersion;
        //         LblStore.Content = info.StoreName;
        //         TxtStoreKey.Text = info.StoreKey;
        //         TxtDcKey.Text = info.DcKey;
        //         TxtRegisterKey.Text = info.RegKey;
        //     }
        // }
        public static Tuple<string, string, string, string, string> GetStoreInfo(string v1, string v2, string text1, string text2, string text3)
        {
            
            return Tuple.Create(v1, v2, text1, text2, text3);
        }
    }
}