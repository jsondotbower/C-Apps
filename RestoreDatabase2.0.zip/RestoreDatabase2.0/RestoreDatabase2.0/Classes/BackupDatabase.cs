﻿namespace RestoreDatabase2._0.Classes
{
    public static class BackupDatabase
    {
        public static string BackupDb(string database)
        {
            return
                $@"BACKUP DATABASE [ARSNET] TO  DISK = N'{database}' WITH COMPRESSION, " +
                "NOINIT,  NAME = N'ARSNET-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10";
        }
    }
}