﻿using System;
using System.IO;
using System.Windows;

namespace RestoreDatabase2._0.Classes
{
    public static class Scrubber
    {
        private const string Datacenter = @"C:\Acusport\Axis Datacenter\AppSettings.config";
        private const string Register = @"C:\Acusport\Axis Register\AppSettings.config";

        public static Tuple<string, string> FixKeys(string dcKey, string rKey)
        {
            var storekey = Queries.StoreKey;
            var result = Db.Query(storekey).ToString();
            var textDc = File.ReadAllText(Datacenter);
            var textR = File.ReadAllText(Register);

            try
            {
                textDc = textDc.Replace(dcKey, result);
                textR = textR.Replace(rKey, result);

                File.WriteAllText(Datacenter, textDc);
                File.WriteAllText(Register, textR);

                var fixuser = Queries.FixUser;
                Db.NonQuery(fixuser);
            }
            catch (Exception)
            {
                MessageBox.Show("Super user fix failed");
            }
            try
            {
                var basepath = Queries.BasePath;
                Db.NonQuery(basepath);

                var timeout = Queries.TimeOut;
                Db.NonQuery(timeout);

                var testServer = Queries.TestServer;
                Db.NonQuery(testServer);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return Tuple.Create(dcKey, rKey);
        }

        public static void PaywareSetup()
        {
            try
            {
                var query = Queries.PaywareSetup;
                Db.NonQuery(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public static void EnableQuickLogin()
        {
            try
            {
                var query = Queries.EnableQuickLogin;
                Db.NonQuery(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public static void SetSuperUser()
        {
            try
            {
                var query = Queries.SetSuperUser;
                Db.NonQuery(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public static void ExecuteEmailFix()
        {
            try
            {
                var query = Queries.EmailFix;
                Db.NonQuery(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public static void UpdateCreditCreds()
        {
            try
            {
                var query = Queries.CreditCreds;
                Db.NonQuery(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public static void IsApiEnabled()
        {
            try
            {
                var query = Queries.IsApiEnabled;
                Db.NonQuery(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}