﻿namespace RestoreDatabase2._0.Classes
{
    public static class DirectoryCheck
    {
        public static string BackupD()
        {
            return @"D:\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\Backup";
        }
    }
}