﻿using System.Collections.ObjectModel;

namespace RestoreDatabase2._0.Classes
{
    public class Directory
    {
        public Directory(string fullPath, string name)
        {
            FullPath = fullPath;
            Name = name;
            Children = new ObservableCollection<object>();
        }
        public string FullPath
        {
            get;
            set;
        }
        public string Name
        {
            get;
            set;
        }
        public ObservableCollection<object> Children
        {
            get;
            private set;
        }
    }
}