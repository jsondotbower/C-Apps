﻿using System;
using System.IO;
using System.Linq;
using System.Windows;

namespace RestoreDatabase2._0.Classes
{
    public static class LoadStoreInfo
    {
        private const string Datacenter = @"C:\Acusport\Axis Datacenter\AppSettings.config";
        private const string Register = @"C:\Acusport\Axis Register\AppSettings.config";

        public static string LoadDbVersion(string dbVersion)
        {
            try
            {
                var version = Queries.DbVersion;

                dbVersion = Db.Query(version).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return dbVersion;
        }

        public static string LoadStorename(string storeName)
        {
            try
            {
                var storename = Queries.StoreName;

                storeName = $@"Store name: {Db.Query(storename)}";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return storeName;
        }

        public static string LoadStoreKey(string storeKey)
        {
            try
            {
                var storekey = Queries.StoreKey;

                storeKey = Db.Query(storekey).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return storeKey;
        }

        public static string LoadDataCenter(string dcKey)
        {
            try
            {
                var storekey = File.ReadLines(Datacenter).Skip(3).Take(1).First();
                var dckey = storekey.Substring(29, 36);

                dcKey = dckey;
            }
            catch (Exception)
            {
                MessageBox.Show("Application could not find the Data Center AppSettings.config file");
            }
            return dcKey;
        }

        public static string LoadRegister(string regKey)
        {
            try
            {
                var line = File.ReadLines(Register).Skip(2).Take(1).First();
                var rkey = line.Substring(29, 36);

                regKey = rkey;
            }
            catch (Exception)
            {
                MessageBox.Show("Application could not find the Register AppSettings.config file");
            }
            return regKey;
        }
    }
}