﻿namespace RestoreDatabase2._0.Classes
{
    public static class Queries
    {
        public static string DbVersion = @"select DbVersion from CompanyStore";
        public static string StoreName = @"select StoreName from CompanyStore";
        public static string StoreKey = @"select StoreKey from CompanyStore";
        public static string FixUser = @"DELETE FROM dbo.EmployeeXRole WHERE EmployeeID = 1;
                                        Update Employee Set EmployeeNumber = '1' Where EmployeeNumber = '100001';
                                        Update Employee Set Active = 1, 
                                        PasswordEncrypted = '', 
                                        PasswordHashed = '8i7IEbi/HLasOuoT0/z+vw==', 
                                        EmployeeNumber = '100001',
                                        LastName = 'User', 
                                        FirstName = 'Super', 
                                        PasswordDate = GETDATE(), 
                                        IsLockedOut = 'False', 
                                        LockedOutDateTime = NULL 
                                        WHERE EmployeeID = 1;
                    
                                        Declare @EmpID as Int = (select employeeid from employee where EmployeeNumber = '100001');
                                        Declare @CountRoles as Int = (Select Count(RoleID) from [Role] where StoreID = 1);
                                        Declare @CompanyID as Int = (Select TOP 1 CompanyID from CompanyStore);
                                        Declare @StoreID as Int = (Select Top 1 StoreNumber from CompanyStore);
                                        declare @roleid as int
                                        declare roles cursor for select roleid from [Role] where StoreID = 1 and RoleDescription not in ('CreditCardSetup','AuditLogView')
                                        open roles
                                        fetch next from roles into @roleid
                                        while @@FETCH_STATUS = 0
                                        begin
                                        IF NOT EXISTS (SELECT * From EmployeeXRole Where EmployeeID = @EmpID and StoreID = @StoreID and @roleid = RoleID)
                                        Insert Into EmployeeXRole Values (@CompanyID,@StoreID,@EmpID,@roleid);
                                        fetch next from roles into @roleid
                                        end
                                        deallocate roles";
        public static string BasePath = @"update CompanyStore set BasePath = '/SharedPath' where CompanyStoreID = 1";
        public static string TimeOut = @"update CompanyStore set POSTimeoutSeconds = 999999999 where CompanyStoreID = 1";
        public static string TestServer = @"use ARSNET
                                         if exists (select * from ElectronicMethod where MethodName = 'AcusportPurchaseOrderWCF') " +
                                         "update ElectronicMethod set CommunicationSettings = '<WCF LOGIN=\"1374\" PASSWORD=\"password\" TEST=\"True\"/>' where MethodName = 'AcusportPurchaseOrderWCF'" +
                                         " else " +
                                         "insert into ElectronicMethod values (1000, 'AcusportPurchaseOrderWCF', '<WCF LOGIN=\"1374\" PASSWORD=\"password\" TEST=\"True\"/>'); " +
                                         "update Vendor set CustomerNumber = '000013740000' where VendorName like 'Acusport%'";
        public static string PaywareSetup = @"declare @prefix as varchar(20) =  substring(convert(varchar,rand()), 3, 20)
                                            IF EXISTS (SELECT * from PaymentTerminal where port = 9001) delete from PaymentTerminal where port = 9001
                                            if EXISTS (SELECT * from KeyValueLookup where KeyName = 'Merchant_CustomerId_Prefix') delete from KeyValueLookup where KeyName = 'Merchant_CustomerId_Prefix'

                                            INSERT INTO PaymentTerminal VALUES 
	                                        ((SELECT CompanyID FROM CompanyStore WHERE IsInstalledStore = 1), 
	                                        (SELECT CompanyStoreID FROM CompanyStore WHERE IsInstalledStore = 1), 
	                                        'Payware', '', 9001, 0, '', 45, 'COM9', 115200, 'None', 8, 2, 
	                                        'https://APIDemo.IPCharge.net/IPCHAPI/RH.aspx', 
	                                        'https://APIDemo.IPCharge.net/IPCHAPI/RH.aspx', 
	                                        'https://APIDemo.IPCharge.net/IPCAdminAPI/RH.ipc', 
	                                        'https://APIDemo.IPCharge.net/IPCAdminAPI/RH.ipc', 
	                                        'B4wXUrRlBvmnAqyCtqAyXrvxpyAhOSboW9GS6FXlr/La5C1leRBmFntPJOacxNFQ', 
	                                        'BOR+YBlqwhvVVw42bFruqmX3IegZa7N2607KcpZ519U=', 
	                                        'cXUA1YX1rWYvLY/sXC2p++VPYKb7AwyVpGQDdsHttu0buXkAGg/KFEKBKLiA9tAX', 
	                                        'd5MeNEsYSLOaOk5Cs1ESuhQDsZoQJab8nVWtdp3XI4QEeqYQPhWyEbrz2DW8G9wmIcj09s7H6UU0SAujxUrq25kZJxABGSEqcD+IgKg67uCjF2N67Rk926WuTaO0qm51', 
	                                        '', 92, CURRENT_TIMESTAMP, 'PaywareSetupScript', 1, NULL, NULL);

                                            INSERT INTO KeyValueLookup VALUES 
                                                ((SELECT TOP 1 CompanyID FROM CompanyStore WHERE CompanyStoreID = 1), 1, 'Merchant_CustomerId_Prefix', @prefix, 'Minnesota', 1, 1, CURRENT_TIMESTAMP, @@SERVERNAME, 1)";
        public static string EnableQuickLogin = @"update CompanyStore set IsQuickLoginEnabled = 1 where CompanyStoreID = 1";
        public static string SetSuperUser = @"update Employee set QuickLogin = '9999' where EmployeeID = 1";
        public static string EmailFix = @"update ScheduledService set Active = 0; 
                                          update MembershipMemberRecurring set ContractCustomerNumber = -1; 
                                          delete from CustomerXEmail";
        public static string CreditCreds = @"delete from EmployeeXRole where RoleID = 94 and EmployeeID = 1";
        public static string IsApiEnabled = @"UPDATE [Role] SET Active = 0 WHERE RoleDescription in ('Cloud','ApiSetup','MultiStoreSetup');
                                            UPDATE CompanyStore SET IsApiEnabled = 0;
                                            UPDATE CompanyStore SET IsMultistoreEnabled = 0;
                                            UPDATE KeyValueLookup SET Value = 'jdonabauer@acusport.com' WHERE KeyName = 'CloudNotificationEmailSupport';
                                            UPDATE KeyValueLookup SET Value = '999999' WHERE KeyName = 'CloudNotificationEmailThrottleTime';";
    }
}