﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Windows;

namespace RestoreDatabase2._0.Classes
{
    public static class RestoreDatabase
    {
        public static void ExecuteRestoreD(string lblbackup, string dcKey, string regKey)
        {
            var database = lblbackup;
            var sql = DriveQueries.GetBackupQueryD(database);
            ExecuteMaster(database, sql, dcKey, regKey);
        }

        public static void ExecuteRestoreC(string lblbackup, string dcKey, string regKey)
        {
            var database = lblbackup;
            var sql = DriveQueries.GetBackupQueryC(database);
            ExecuteMaster(database, sql, dcKey, regKey);
        }

        public static void ExecuteMaster(string database, string sql, string dcKey, string regKey)
        {
            var con = Db.GetMasterConn();
            var dckey = LoadStoreInfo.LoadDataCenter(dcKey);
            var rkey = LoadStoreInfo.LoadRegister(regKey);
            string dbTrim = Path.GetFileNameWithoutExtension(database);
            try
            {
                con.Open();
                var command = new SqlCommand(sql, con);
                command.CommandTimeout = 0;
                command.ExecuteNonQuery();
                con.Close();

                Scrubber.ExecuteEmailFix();
                Scrubber.FixKeys(dckey, rkey);
                Scrubber.PaywareSetup();
                Scrubber.IsApiEnabled();
                Scrubber.UpdateCreditCreds();
                Scrubber.SetSuperUser();
                Scrubber.EnableQuickLogin();
                MessageBox.Show("Database " + dbTrim + " restored and scrubbed successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}