﻿using System.Collections.ObjectModel;

namespace RestoreDatabase2._0.Classes
{
    public class Drive
    {
        public Drive(string name, bool isReady)
        {
            Name = name;
            IsReady = isReady;
            Children = new ObservableCollection<object>();
        }
        public string Name
        {
            get;
            set;
        }
        public bool IsReady
        {
            get;
            set;
        }
        public ObservableCollection<object> Children
        {
            get;
            private set;
        }
    }
}